﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Program
    {
        #region HwValidEmail
        //static void Main()
        //{
        //    Console.Write("How many emails would You want to input: ");
        //    int countOfEmails = int.Parse(Console.ReadLine());
        //    string[] emails = new string[countOfEmails];
        //    string firtsEmailList ="";
        //    string secondEmailList = "";


        //    for (int i = 0; i < emails.Length; i++)
        //    {
        //        Console.Write($"Please, input {i + 1}th email: ");
        //        string email = Console.ReadLine();
        //        emails[i] = email;
        //        if (email.IndexOf('@') == -1)
        //        {
        //            firtsEmailList = firtsEmailList + " " + email;

        //        }
        //        else
        //        {
        //            secondEmailList = secondEmailList + " " + email;
        //        }
        //    }
        //    Console.WriteLine("Invalid emails list:" + firtsEmailList);
        //    Console.WriteLine("Valid emails list:" + secondEmailList);
        //    Console.ReadKey();
        //}


        #endregion

        #region Advange

        //static void Main()
        //{
        //    Console.WriteLine("How many numbers would You want to input:");
        //    int countOfNumbers = int.Parse(Console.ReadLine());
        //    int[] numbers =new int[countOfNumbers];
        //    string firstList="";
        //    string secondList="";
        //    int total = 0;
        //    int count = 0;
        //    for (int i = 0; i < numbers.Length; i++)
        //    {
        //        Console.Write($"Please, input {i + 1}th number: ");
        //       int number = int.Parse(Console.ReadLine());
        //        if (number > 18)
        //        {
        //            count++;
        //            total += number;
        //           firstList = firstList + number.ToString() +  " ";
                    
        //        }
        //        else
        //        {
        //            secondList = secondList + number.ToString() + " ";
        //        }

        //    }
        //    int myAdvange = total / count;
        //    Console.WriteLine("18+ old is " + count + " person.");
        //    Console.WriteLine("18+ old advange is " + myAdvange + " old.");
        //    Console.ReadKey();
        //}

        #endregion
        
    }
  
}
